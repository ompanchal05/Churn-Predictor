import pandas as pd

class FeatureEngineer:
    def __init__(self):
        self.service_cols = [
            "PhoneService", "OnlineBackup", "TechSupport",
            "StreamingMovies", "StreamingTV"
        ]

    def add_features(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        # Revenue relative to tenure
        df["Revenue_per_Month"] = df["TotalCharges"] / (df["tenure"] + 1)

        # Count number of subscribed services
        df["Service_Count"] = df[self.service_cols].sum(axis=1)

        return df
