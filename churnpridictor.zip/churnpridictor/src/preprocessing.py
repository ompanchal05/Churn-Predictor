import pandas as pd

class Preprocessor:

    def __init__(self):
        # These are numeric columns, but now we check before using them
        self.numeric_cols = [
            "SeniorCitizen", "tenure", "MonthlyCharges", "TotalCharges"
        ]

        # Columns expected to be YES/NO but may be missing
        self.binary_map = {
            "Yes": 1, "No": 0, "yes": 1, "no": 0, True: 1, False: 0
        }

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:

        # 🔥 FIX: Add missing numeric columns safely
        for col in self.numeric_cols:
            if col not in df.columns:
                df[col] = 0  # default value if missing

            df[col] = pd.to_numeric(df[col], errors="coerce")

        df.fillna(0, inplace=True)
        return df

    def encode(self, df: pd.DataFrame) -> pd.DataFrame:
        # Convert yes/no columns to 1/0 without errors
        for col in df.columns:
            if df[col].astype(str).str.lower().isin(["yes", "no"]).any():
                df[col] = df[col].replace(self.binary_map)

        # Convert remaining categorical columns
        for col in df.select_dtypes(include="object").columns:
            df[col] = df[col].astype('category').cat.codes

        return df

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = self.clean(df)
        df = self.encode(df)
        return df
