import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier
from src.preprocessing import Preprocessor
from src.feature_engineering import FeatureEngineer

class RetentionModelTrainer:
    def __init__(self):
        self.model = None

    def train(self, df: pd.DataFrame, target_col="churn"):
        print("📌 Starting preprocessing and feature engineering...")

        prep = Preprocessor()
        fe = FeatureEngineer()

        df = prep.transform(df)
        df = fe.add_features(df)

        X = df.drop(target_col, axis=1)
        y = df[target_col]

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, stratify=y, random_state=42
        )

        sm = SMOTE(random_state=42)
        X_train_bal, y_train_bal = sm.fit_resample(X_train, y_train)

        print("📌 Training XGBoost model...")
        model = XGBClassifier(eval_metric="logloss")
        model.fit(X_train_bal, y_train_bal)

        self.model = model
        return model, (X_test, y_test)

    def save(self, path="saved_models/retention_model.pkl"):
        if self.model:
            pickle.dump(self.model, open(path, "wb"))
            print(f"✅ Model saved to {path}")
        else:
            raise ValueError("⚠ No model trained yet.")
