import pandas as pd
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier
import pickle

# Load dataset (this must be the same format users upload)
df = pd.read_csv("data/telecom_churn.csv")

# Convert Yes/No to numeric
yes_no_cols = [col for col in df.columns if df[col].astype(str).str.lower().isin(["yes", "no"]).any()]
for col in yes_no_cols:
    df[col] = df[col].replace({"yes": 1, "no": 0, "Yes": 1, "No": 0})

# Encode all other non-numeric fields
le = LabelEncoder()
for col in df.select_dtypes(include="object").columns:
    if col != "churn":  # Do NOT encode target
        df[col] = le.fit_transform(df[col].astype(str))

# Train-test split not needed for full dataset training
X = df.drop("churn", axis=1)
y = df["churn"]

model = XGBClassifier()
model.fit(X, y)

# Save trained model + feature names
pickle.dump(model, open("saved_models/retention_model.pkl", "wb"))
pickle.dump(list(X.columns), open("saved_models/model_features.pkl", "wb"))

print("\n🎉 MODEL TRAINED SUCCESSFULLY!")
print(f"Features Used: {list(X.columns)}")
