from src.model_train import RetentionModelTrainer
import pandas as pd

df = pd.read_csv("data/telecom_churn.csv")

trainer = RetentionModelTrainer()
model, test_data = trainer.train(df)

trainer.save()
print(" Training Complete!")
